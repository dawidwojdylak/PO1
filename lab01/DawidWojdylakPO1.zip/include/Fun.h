#pragma once 
#include "FElementarne.h"

class Fun{

public:
  virtual double  wartosc(double v) const = 0;

};