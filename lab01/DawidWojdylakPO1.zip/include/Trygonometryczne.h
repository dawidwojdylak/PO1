#pragma once
#include "Fun.h"
#include <math.h>

class Sinus: public Fun
{
public:
  //Sinus(double)
  double wartosc(double v) { return sin (v); }

  private:
    //double _val;
};