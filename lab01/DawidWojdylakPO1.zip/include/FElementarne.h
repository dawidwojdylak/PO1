#pragma once
#include "Fun.h"



class Liniowa: public Fun{
public:
  static Liniowa * utworz() { return a; }
  Liniowa * a(double n) { _a = n; return b; }
  void b(double n) { _b = n; }
  
private:
  double _a, _b;
};